import React from 'react'
import ReactDOM from 'react-dom/client'
/*import Login from './login_page/Login' <Login/> */
import MainCalendar from './main_page/MainCalendar';



ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
   <MainCalendar/>
  </React.StrictMode>,
)
