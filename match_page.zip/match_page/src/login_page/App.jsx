import { useState } from 'react';
import styles from './App.module.css'
import axios from 'axios';
 /* import MainCalendar from './main_page/MainCalendar'; */

const App = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLoginClick = async () => {
    try {
      const response = await axios.post('/auth/login', { email, password }); // Adjust the endpoint URL
      if (response.status === 200) {
       /* <MainCalendar/>  {error && <p className={syles.errorText}>Account does not exist.</p>}*/ <h2> good job</h2>
      }
    } catch (error) {
      if (error.response && error.response.status === 401) {
        setError('Account does not exist.');
      } else {
        setError('An error occurred. Please try again later.');
      }
    }
  };
  return (
    <div className={styles.formBox}>
        <>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder=" example123@gmail.com "
            className={styles.infoInput}
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="password"
          />
          <div className={styles.loginNow}>
            <button onClick={handleLoginClick}>Login now</button>
          </div>
        </>
    </div>
  );
};

export default App;